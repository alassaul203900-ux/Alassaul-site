/* ALASSAUL 2026 — Smart Map Core */
const ALASSAUL_MAP = {
  locations: [
    {id:'trabzon',name:'طرابزون',lat:41.0015,lng:39.7178,type:'city'},
    {id:'uzungol',name:'أوزنجول',lat:40.6200,lng:40.2880,type:'nature'},
    {id:'rize',name:'ريزا',lat:41.0201,lng:40.5234,type:'city'},
    {id:'ayder',name:'آيدر',lat:40.9530,lng:41.0950,type:'highland'},
    {id:'sumela',name:'دير سوميلا',lat:40.6890,lng:39.6580,type:'historical'},
    {id:'samsun',name:'سامسون',lat:41.2867,lng:36.3300,type:'city'},
    {id:'ordu',name:'أوردو',lat:40.9839,lng:37.8764,type:'city'},
    {id:'giresun',name:'غيرسون',lat:40.9128,lng:38.3895,type:'city'},
    {id:'istanbul',name:'إسطنبول',lat:41.0082,lng:28.9784,type:'city'}
  ],
  findLocation(id) { return this.locations.find(location => location.id === id); },
  search(text) {
    const normalize = value => String(value || '').toLowerCase().trim()
      .replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي');
    const q=normalize(text);
    if(!q) return this.locations;
    return this.locations.filter(location =>
      normalize(location.name).includes(q) || normalize(location.id).includes(q) || normalize(location.type).includes(q)
    );
  }
};
window.ALASSAUL_MAP = ALASSAUL_MAP;
