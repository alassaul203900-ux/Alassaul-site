document.addEventListener("DOMContentLoaded", () => {

  // V392: visible connection status for mobile/offline use.
  const connectionStatus = document.createElement("div");
  connectionStatus.className = "connection-status visually-hidden";
  connectionStatus.setAttribute("role", "status");
  connectionStatus.setAttribute("aria-live", "polite");
  document.body.appendChild(connectionStatus);
  const updateConnectionStatus = () => {
    const offline = !navigator.onLine;
    connectionStatus.textContent = offline ? "أنت الآن دون اتصال — الصفحات المحفوظة ما زالت متاحة." : "تم استعادة الاتصال بالإنترنت.";
    connectionStatus.classList.toggle("is-visible", offline);
    if (!offline) {
      window.clearTimeout(updateConnectionStatus._timer);
      updateConnectionStatus._timer = window.setTimeout(() => connectionStatus.classList.remove("is-visible"), 3200);
    }
  };
  window.addEventListener("online", updateConnectionStatus);
  window.addEventListener("offline", updateConnectionStatus);
  updateConnectionStatus();

  const year = new Date().getFullYear();
  document.querySelectorAll(".current-year").forEach(el => el.textContent = year);
  document.querySelectorAll("footer").forEach(f=>{ if(!f.querySelector(".alassaul-extra-links")){ const d=document.createElement("div"); d.className="alassaul-extra-links"; d.innerHTML=`<a href="login.html">تسجيل الدخول</a> · <a href="guestbook.html">دفتر الزوار</a> · <a href="control-room.html">غرفة التحكم</a> · <a href="it.html">IT</a>`; f.appendChild(d); } });
  const conversation = document.querySelector("#aiConversation");
  const question = document.querySelector("#aiQuestion");
  const askButton = document.querySelector("#askAI");
  const quickPrompts = Array.from(document.querySelectorAll(".quick-prompt"));
  const fallbackImages = {"hero.jpg":"assets/hero-fallback.svg","trabzon.jpg":"assets/trabzon-fallback.svg","uzungol.jpg":"assets/uzungol-fallback.svg","rize.jpg":"assets/rize-fallback.svg","ayder.jpg":"assets/ayder-fallback.svg","sumela.jpg":"assets/sumela-fallback.svg"};
  document.querySelectorAll("img").forEach(img => img.addEventListener("error", () => {
    const key = (img.getAttribute("src") || "").split("/").pop();
    const alt = (img.getAttribute("alt") || "").toLowerCase();
    const semanticFallback = alt.includes("طرابزون") || alt.includes("trabzon") ? "assets/trabzon-fallback.svg" : alt.includes("أوزنجول") || alt.includes("اوزنجول") || alt.includes("uzungol") ? "assets/uzungol-fallback.svg" : alt.includes("ريزا") || alt.includes("rize") ? "assets/rize-fallback.svg" : alt.includes("آيدر") || alt.includes("ايدر") || alt.includes("ayder") ? "assets/ayder-fallback.svg" : alt.includes("سوميلا") || alt.includes("sumela") ? "assets/sumela-fallback.svg" : null;
    const target = fallbackImages[key] || semanticFallback || "assets/hero-fallback.svg";
    if (img.getAttribute("src") !== target) img.src = target;
  }, {once:true}));
  const backButton = document.querySelector("#backToTop");
  if (backButton) { window.addEventListener("scroll", () => backButton.classList.toggle("show", window.scrollY > 400), {passive:true}); backButton.addEventListener("click", () => window.scrollTo({top:0,behavior:"smooth"})); }
  const searchInput = document.querySelector("#searchInput, .globalSearch"), searchResult = document.querySelector("#searchResults"), searchButton = document.querySelector("#searchButton, .globalSearchBtn");
  const renderSearch = () => {
    const value = searchInput ? searchInput.value.trim() : "";
    if (!searchResult || !value || !window.ALASSAUL_SEARCH) { if (searchResult) searchResult.innerHTML = ""; return; }
    const result = window.ALASSAUL_SEARCH.globalSearch(value);
    const groups = [
      ...(result.cities || []).map(x => ({type:"مدينة", name:x.name, desc:x.description, href:x.file})),
      ...(result.places || []).map(x => ({type:"مكان", name:x.name, desc:x.description, href:x.file})),
      ...(result.programs || []).map(x => ({type:"برنامج", name:x.title, desc:x.description, href:"programs.html"})),
      ...(result.services || []).map(x => ({type:"خدمة", name:x.name, desc:x.description, href:x.file}))
    ];
    if (!groups.length) {
      searchResult.innerHTML = '<div class="search-box"><h4>لم نجد نتيجة مباشرة</h4><p>جرّب اسم مدينة، مكان، طبيعة، فندق، مطعم أو عدد الأيام.</p><a class="btn" href="ai.html">اسأل العسول AI</a></div>';
      return;
    }
    searchResult.innerHTML = '<div class="search-box"><h4>نتائج البحث</h4>' +
      groups.slice(0, 10).map(item => '<a class="search-result" href="' + escapeHTML(item.href) + '">' +
        '<strong>' + escapeHTML(item.name) + '</strong><small>' + escapeHTML(item.type) + '</small>' +
        (item.desc ? '<span>' + escapeHTML(item.desc) + '</span>' : '') + '</a>').join("") +
      '</div>';
  };
  if (searchInput) searchInput.addEventListener("input", renderSearch);
  if (searchButton) searchButton.addEventListener("click", renderSearch);
  if (searchInput) searchInput.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); renderSearch(); } });
  const globalSearchInput = document.querySelector(".globalSearch");
  if(globalSearchInput && !document.querySelector("#searchResults")){
    const r=document.createElement("div"); r.id="searchResults"; r.className="global-search-results"; globalSearchInput.closest(".global-search")?.parentElement?.appendChild(r);
  }
  if(!document.querySelector(".alassaul-floating-ai")){
    const fab=document.createElement("a"); fab.className="alassaul-floating-ai"; fab.href="ai.html#ai-chat"; fab.setAttribute("aria-label","افتح العسول AI"); fab.textContent="🤖 العسول"; document.body.appendChild(fab);
  }
  const aiButton=document.querySelector("#aiButton"), aiResponse=document.querySelector("#aiResponse");
  if(aiButton && aiResponse) aiButton.addEventListener("click",()=>{aiResponse.innerHTML='أهلاً بك 🌿 أنا العسول AI. <a href="ai.html">افتح المحادثة</a> وابدأ رحلتك.';});
  const normalizeArabic=value=>String(value||"").toLowerCase().replace(/[أإآ]/g,"ا").replace(/ى/g,"ي").replace(/[٠-٩]/g,d=>String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
  const escapeHTML=value=>{const div=document.createElement("div");div.textContent=value;return div.innerHTML;};

  const ALASSAUL_MAP_POINTS={
    trabzon:{name:"طرابزون",lat:41.0015,lng:39.7178,page:"trabzon.html"},
    uzungol:{name:"أوزنجول",lat:40.6200,lng:40.2880,page:"uzungol.html"},
    rize:{name:"ريزا",lat:41.0201,lng:40.5234,page:"rize.html"},
    ayder:{name:"آيدر",lat:40.9520,lng:41.0930,page:"ayder.html"},
    sumela:{name:"سوميلا",lat:40.6892,lng:39.6572,page:"sumela.html"}
  };
  const mapLink=(key)=>{
    const p=ALASSAUL_MAP_POINTS[key]; if(!p)return "";
    const q=encodeURIComponent(`${p.lat},${p.lng}`);
    return `<div class="ai-map-actions"><a class="btn" href="map.html?lat=${p.lat}&lng=${p.lng}&place=${encodeURIComponent(p.name)}">🗺️ افتح على خريطة العسول</a><a class="btn btn-outline" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=${q}">🚗 الاتجاهات</a></div>`;
  };

  const buildContext=()=>{
    const cities=(window.ALASSAUL_CITIES||[]).map(x=>`${x.name}: ${x.description||""}`).join("\n");
    const places=(window.ALASSAUL_PLACES||[]).map(x=>`${x.name} (${x.city||""}): ${x.description||""} [${(x.tags||[]).join(", ")}]`).join("\n");
    const programs=(window.ALASSAUL_PROGRAMS||[]).map(x=>`${x.title}: ${x.description||""}`).join("\n");
    const services=window.ALASSAUL_API_MANAGER?.publicSummary?.()||"";
    return `المدن:\n${cities}\nالأماكن:\n${places}\nالبرامج:\n${programs}\nالخدمات المتاحة للعسول:\n${services}`;
  };
  const historyForAI=()=>{
    if(!conversation)return [];
    return Array.from(conversation.querySelectorAll(".user-message,.ai-message")).slice(-8).map(el=>({
      role:el.classList.contains("user-message")?"user":"assistant",
      content:el.textContent.trim().slice(0,1200)
    }));
  };
  const shouldTryRemote=text=>Boolean(window.ALASSAUL_CONFIG?.aiEndpoint);
  let remoteAIInFlight=false;
  let aiBusy=false;
  let remoteAIAvailable=null;
  const askRemoteAI=async (text,history=[])=>{
    if(remoteAIInFlight) throw new Error("AI request already in progress");
    remoteAIInFlight=true;
    const endpoint=window.ALASSAUL_CONFIG?.aiEndpoint || "/.netlify/functions/ai";
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),23000);
    try{
      const response=await fetch(endpoint,{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({question:text,history,context:buildContext()}),
        signal:controller.signal
      });
      const data=await response.json().catch(()=>({}));
      if(!response.ok||!data.ok){
        const retryAfter=response.headers.get("Retry-After");
        const error=new Error(data.message||"AI unavailable");
        error.code=data.code||"AI_UNAVAILABLE";
        error.retryAfter=retryAfter;
        throw error;
      }
      return data;
    }finally{
      clearTimeout(timeout);
      remoteAIInFlight=false;
    }
  };
  let voiceMode=false;
  let voiceBusy=false;
  let mediaRecorder=null;
  let recordingStream=null;
  let recordingChunks=[];
  let voiceAudio=null;
  let silenceTimer=null;
  let recordingStartedAt=0;
  let speechDetected=false;
  let audioContext=null;
  let analyser=null;
  let analyserData=null;
  let silenceRaf=0;
  let voiceRecognition=null;
  let voiceUsingRecognition=false;
  let voiceRecognitionRestart=false;
  const VoiceRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
  const voiceAI=document.querySelector("#voiceAI");
  const voiceStatus=document.createElement("span");
  voiceStatus.className="voice-status";
  if(voiceAI) voiceAI.insertAdjacentElement("afterend",voiceStatus);
  const aiConfigStatus=document.querySelector("#ai-config-status");
  if(aiConfigStatus){
    fetch("/.netlify/functions/health",{cache:"no-store"}).then(r=>r.json()).then(d=>{
      remoteAIAvailable=Boolean(d?.checks?.aiAssistant);
      aiConfigStatus.textContent=remoteAIAvailable?`🟢 العسول متصل — ${d?.ai?.gateway||'AI Gateway'} / ${d?.ai?.model||'AI'}`:'🟡 محرك العسول غير مفعّل بعد في هذا الـDeploy. لا تقلق: الواجهة تعمل، لكن الإجابات المفتوحة لن تُخمن.';
      aiConfigStatus.classList.add("is-visible");
    }).catch(()=>{aiConfigStatus.textContent="🟡 تعذر فحص اتصال العسول الآن.";aiConfigStatus.classList.add("is-visible");});
  }
  const showVoiceHelp=msg=>{voiceStatus.textContent=msg;voiceStatus.classList.add("is-visible");};
  const preferredMime=()=>{
    const list=["audio/webm;codecs=opus","audio/webm","audio/mp4","audio/ogg;codecs=opus"];
    return list.find(x=>window.MediaRecorder?.isTypeSupported?.(x))||"";
  };
  const stopVoiceStream=()=>{
    if(silenceTimer){clearTimeout(silenceTimer);silenceTimer=null;}
    if(silenceRaf){cancelAnimationFrame(silenceRaf);silenceRaf=0;}
    try{audioContext?.close();}catch(_){}
    audioContext=null; analyser=null; analyserData=null;
    if(recordingStream){recordingStream.getTracks().forEach(t=>t.stop());recordingStream=null;}
  };
  const watchForSilence=()=>{
    if(!mediaRecorder || mediaRecorder.state!=="recording" || !analyser) return;
    analyser.getByteTimeDomainData(analyserData);
    let sum=0; for(const v of analyserData){const d=(v-128)/128; sum+=d*d;}
    const rms=Math.sqrt(sum/analyserData.length);
    const elapsed=Date.now()-recordingStartedAt;
    if(rms>0.035){
      speechDetected=true;
      if(silenceTimer){clearTimeout(silenceTimer);silenceTimer=null;}
    }else if(speechDetected && !silenceTimer && elapsed>900){
      silenceTimer=setTimeout(()=>{silenceTimer=null;if(mediaRecorder?.state==="recording") stopListening();},1100);
    }
    if(elapsed<15000 && mediaRecorder?.state==="recording") silenceRaf=requestAnimationFrame(watchForSilence);
    else if(elapsed>=15000 && mediaRecorder?.state==="recording") stopListening();
  };
  const browserMaleSpeak=async(text)=>{
    if(!('speechSynthesis' in window)) return false;
    const value=String(text||'').trim(); if(!value)return false;
    try{
      const synth=window.speechSynthesis;
      synth.cancel();
      let voices=synth.getVoices();
      if(!voices.length){
        await new Promise(resolve=>{let done=false;const finish=()=>{if(done)return;done=true;try{synth.removeEventListener('voiceschanged',finish);}catch(_){}resolve();};try{synth.addEventListener('voiceschanged',finish,{once:true});}catch(_){}setTimeout(finish,700);});
        voices=synth.getVoices();
      }
      const ar=voices.filter(v=>/^ar(?:[-_]|$)/i.test(v.lang));
      const maleWords=/male|man|david|daniel|alex|fred|george|thomas|google.*male|ذكر|رجل/i;
      const chosen=ar.find(v=>maleWords.test(v.name)) || ar[0] || voices.find(v=>maleWords.test(v.name)) || voices[0];
      if(!chosen)return false;
      await new Promise(resolve=>{
        const u=new SpeechSynthesisUtterance(value);
        u.lang=chosen.lang||'ar-SA'; u.voice=chosen; u.rate=.94; u.pitch=.9; u.volume=1;
        u.onend=resolve; u.onerror=resolve;
        synth.speak(u);
      });
      return true;
    }catch(_){return false;}
  };
  const speakReply=async text=>{
    if(!voiceMode)return false;
    const clean=String(text||'').slice(0,3500);
    try{
      const r=await fetch(window.ALASSAUL_CONFIG?.ttsEndpoint||'/.netlify/functions/tts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:clean})});
      const ct=r.headers.get('content-type')||'';
      if(!r.ok||!ct.includes('audio'))throw new Error('TTS unavailable');
      const blob=await r.blob();
      if(voiceAudio){try{voiceAudio.pause()}catch(_){} URL.revokeObjectURL(voiceAudio.dataset.url||'');}
      const url=URL.createObjectURL(blob);
      const audio=new Audio(url); audio.preload='auto'; audio.dataset.url=url; audio.playsInline=true; voiceAudio=audio;
      await new Promise(resolve=>{
        let settled=false; const done=()=>{if(settled)return;settled=true;try{URL.revokeObjectURL(url)}catch(_){}voiceAudio=null;resolve();};
        audio.onended=done; audio.onerror=done;
        audio.play().catch(done);
      });
      return true;
    }catch(e){
      const spoken=await browserMaleSpeak(clean);
      if(!spoken)showVoiceHelp('🔊 تعذر تشغيل الصوت الرجالي الآن. الرد ظاهر كتابيًا؛ جرّب المحادثة مرة أخرى.');
      return spoken;
    }
  };
  const stripForVoice=html=>String(html||'').replace(/<br\s*\/?\s*>/gi,'. ').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();
  const appendAI=async(html,live=false)=>{
    const badge=live?'<small class="ai-live-badge">معلومة حديثة</small>':'';
    conversation.insertAdjacentHTML('beforeend',`<div class="ai-message">${badge}${html}</div>`);
    conversation.scrollTop=conversation.scrollHeight;
    await speakReply(stripForVoice(html));
  };
  const localReply=(text,history=[])=>{
    const q=normalizeArabic(text);
    if(/^(اهلا|مرحبا|السلام|هلا|صباح|مساء)/.test(q)) return 'وعليكم السلام ورحمة الله وبركاته 🌿 أنا العسول. اكتب طلبك مباشرة وسأساعدك فيه.';
    if(q.includes('طريق')||q.includes('كيف اروح')||q.includes('الوصول')) return 'أبشر. أرسل لي اسم نقطة الانطلاق واسم الوجهة، وسأرتب لك طريقة الوصول. وللخريطة المباشرة استخدم خريطة العسول.';
    if(q.includes('اوزنجول')||q.includes('اوزونجول')||q.includes('uzungol')) return 'أوزنجول من أبرز وجهات طرابزون للطبيعة والبحيرة والجبال. إذا أخبرتني بعدد الأيام أرتب لك برنامجًا مناسبًا. <a href="uzungol.html">فتح صفحة أوزنجول</a>.';
    if(q.includes('ايدر')||q.includes('ayder')) return 'آيدر تجمع الهضبة والشلالات ووادي فرتينا والطبيعة الجبلية. إذا أردت، أرتبها لك كرحلة يومية أو مع مبيت. <a href="ayder.html">فتح صفحة آيدر</a>.';
    if(q.includes('طرابزون')||q.includes('trabzon')) return 'طرابزون هي نقطة انطلاق ممتازة للشمال التركي، ومنها تصل بسهولة إلى سوميلا وأوزنجول وآيدر. قل لي كم يومًا معك وسأرتب البرنامج.';
    if(q.includes('سوميلا')||q.includes('sumela')) return 'دير سوميلا من أبرز معالم المنطقة الجبلية قرب طرابزون. أقدر أرتب لك زيارته مع ماتشكا وبقية اليوم.';
    if(q.includes('دين')||q.includes('قران')||q.includes('قرآن')||q.includes('حديث')||q.includes('صلاه')||q.includes('صلاة')) return 'أقدر أساعدك بالمعلومات الدينية الموثوقة وشرح النصوص والسيرة. أما الفتوى الخاصة أو المسألة الخلافية فسأوضح أنها تحتاج مصدرًا شرعيًا موثوقًا.';
    if(q.includes('برمج')||q.includes('كود')||q.includes('javascript')||q.includes('html')||q.includes('css')) return 'أرسل الكود أو رسالة الخطأ كما ظهرت لك، وسأحدد المشكلة وأشرح لك الحل خطوة بخطوة.';
    if(q.includes('فندق')||q.includes('فنادق')) return 'قل لي المدينة، عدد الليالي، عدد الأشخاص، والميزانية التقريبية، وسأساعدك في اختيار الأنسب.';
    if(q.includes('مطعم')||q.includes('مطاعم')) return 'قل لي المدينة ونوع الأكل والميزانية، وسأساعدك في تضييق الخيارات.';
    if(q.match(/(^|\s)(4|اربع|أربع)(\s|$)/)) return 'لأربعة أيام: طرابزون → سوميلا → أوزنجول → آيدر، مع توزيع مريح حسب مكان السكن.';
    if(q.match(/(^|\s)(5|خمس)(\s|$)/)) return 'لخمسة أيام: طرابزون → سوميلا → أوزنجول → آيدر → يوم مرن للمدينة أو ريزا.';
    if(q.match(/(^|\s)(7|سبع)(\s|$)/)) return 'لسبعة أيام يمكن الجمع بين طرابزون وسوميلا وأوزنجول وآيدر وريزا بدون ضغط.';
    return 'وصلتني رسالتك 🌿 لكن العسول يعمل حاليًا بالوضع المحلي، وليس بالذكاء الاصطناعي الكامل؛ لذلك لن أخمّن جوابًا على سؤال لا أملك له قاعدة موثوقة. فعّل خدمة AI في Netlify وسأتعامل مع الأسئلة المفتوحة بشكل ذكي وطبيعي.';
  };
  const ask=async text=>{
    if(aiBusy)return;
    const clean=String(text||'').trim().slice(0,1200);
    if(!clean||!conversation)return;
    const priorHistory=historyForAI(); aiBusy=true; voiceBusy=true;
    if(askButton){askButton.disabled=true;askButton.setAttribute('aria-busy','true');}
    conversation.insertAdjacentHTML('beforeend',`<div class="user-message">${escapeHTML(clean)}</div>`);
    if(question)question.value='';
    conversation.insertAdjacentHTML('beforeend',`<div class="ai-message" data-ai-loading="1">⏳ لحظة، العسول معك...</div>`);
    conversation.scrollTop=conversation.scrollHeight;
    try{
      if(remoteAIAvailable===false){
        const loading=conversation.querySelector('[data-ai-loading="1"]');if(loading)loading.remove();
        await appendAI(localReply(clean,priorHistory));
      }else{
        try{
          const data=await askRemoteAI(clean,priorHistory);
          const loading=conversation.querySelector('[data-ai-loading="1"]');if(loading)loading.remove();
          await appendAI(escapeHTML(data.answer).replace(/\n/g,'<br>'),Boolean(data.live));
        }catch(error){
          console.warn('Remote AI unavailable.',error);
          const loading=conversation.querySelector('[data-ai-loading="1"]');if(loading)loading.remove();
          const msg=error?.message||'تعذر الاتصال بمحرك العسول.';
          await appendAI(`<strong>⚠️ العسول يحتاج اتصال محرك الذكاء الاصطناعي.</strong><br>${escapeHTML(msg)}<br><small>لن أعطيك جوابًا عشوائيًا مختلفًا عن سؤالك. افتح حالة الاتصال في الأسفل أو أعد النشر بعد تفعيل AI Gateway.</small>`);
        }
      }
    }finally{
      aiBusy=false;voiceBusy=false;
      if(askButton){askButton.disabled=false;askButton.removeAttribute('aria-busy');}
      if(voiceMode&&!voiceAudio&&!mediaRecorder&&!voiceUsingRecognition) setTimeout(startListening,450);
    }
  };
  async function transcribe(blob){
    const endpoint=window.ALASSAUL_CONFIG?.transcribeEndpoint||'/.netlify/functions/transcribe';
    const form=new FormData(); form.append('file',blob,'alassaul-voice.webm');
    const r=await fetch(endpoint,{method:'POST',body:form});
    const d=await r.json().catch(()=>({}));
    if(!r.ok||!d.ok){const e=new Error(d.message||'تعذر فهم الصوت');e.code=d.code||'TRANSCRIBE_ERROR';throw e;}
    return String(d.text||'').trim();
  }
  async function startListening(){
    if(!voiceMode||voiceBusy||mediaRecorder?.state==='recording'||voiceUsingRecognition)return;
    // Prefer a real audio recording path on Android. This avoids Chrome's Web Speech
    // start/stop flapping and lets the server perform Arabic transcription consistently.
    if(navigator.mediaDevices?.getUserMedia&&window.MediaRecorder){
      try{
        recordingStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
        const mime=preferredMime(); mediaRecorder=mime?new MediaRecorder(recordingStream,{mimeType:mime}):new MediaRecorder(recordingStream);
        recordingChunks=[]; speechDetected=false; recordingStartedAt=Date.now();
        try{
          audioContext=new (window.AudioContext||window.webkitAudioContext)();
          if(audioContext.state==='suspended')await audioContext.resume();
          const source=audioContext.createMediaStreamSource(recordingStream);
          analyser=audioContext.createAnalyser(); analyser.fftSize=512; analyserData=new Uint8Array(analyser.fftSize); source.connect(analyser);
        }catch(_){audioContext=null;analyser=null;analyserData=null;}
        mediaRecorder.ondataavailable=e=>{if(e.data?.size)recordingChunks.push(e.data)};
        mediaRecorder.onstop=async()=>{
          const recorderType=mediaRecorder?.mimeType||mime||'audio/webm';
          const blob=new Blob(recordingChunks,{type:recorderType});
          mediaRecorder=null; recordingChunks=[]; stopVoiceStream();
          if(!voiceMode||blob.size<1200){if(voiceMode)setTimeout(startListening,500);return;}
          voiceBusy=true; showVoiceHelp('⏳ فهمت التسجيل… أرسلته للعسول الآن.');
          try{
            const text=await transcribe(blob);
            if(!text)throw new Error('TRANSCRIBE_EMPTY');
            showVoiceHelp('🧠 فهمت كلامك، سأجيبك الآن…');
            await ask(text);
          }catch(e){
            voiceBusy=false;
            if(e?.code==='TRANSCRIBE_NOT_CONFIGURED'||e?.code==='TRANSCRIBE_PROVIDER_ERROR') showVoiceHelp('⚠️ خدمة الصوت غير مفعّلة في هذا الـDeploy. بعد نشر النسخة Production مع AI Gateway سيعمل الاستماع والإجابة الصوتية.');
            else showVoiceHelp('⚠️ لم أفهم التسجيل. حاول الكلام بوضوح مرة أخرى.');
            if(voiceMode)setTimeout(startListening,900);
          }
        };
        mediaRecorder.start(250);
        voiceAI.textContent='🛑 إيقاف وإرسال'; voiceAI.classList.add('listening');
        showVoiceHelp('🎙️ العسول يستمع لك… تكلم الآن، ثم اضغط إيقاف وإرسال أو انتظر التوقف التلقائي.');
        if(analyser)watchForSilence();
        return;
      }catch(e){
        stopVoiceStream();
        if(e?.name==='NotAllowedError'){showVoiceHelp('⚠️ اسمح للمتصفح باستخدام الميكروفون ثم جرّب مرة أخرى.');voiceMode=false;return;}
        // Fall through to browser speech recognition if audio recording is unavailable.
      }
    }
    if(VoiceRecognition){
      try{
        if(!voiceRecognition){
          voiceRecognition=new VoiceRecognition();
          voiceRecognition.lang='ar-SA'; voiceRecognition.interimResults=false; voiceRecognition.continuous=false; voiceRecognition.maxAlternatives=1;
          voiceRecognition.onstart=()=>{voiceUsingRecognition=true;voiceAI?.classList.add('listening');voiceAI&&(voiceAI.textContent='🛑 إيقاف الاستماع');showVoiceHelp('🎙️ العسول يستمع لك… تكلم الآن.');};
          voiceRecognition.onresult=async e=>{
            const text=String(e.results?.[0]?.[0]?.transcript||'').trim(); if(!text)return;
            voiceBusy=true; showVoiceHelp('🧠 فهمت كلامك، سأجيبك الآن…');
            try{await ask(text);}finally{voiceBusy=false;}
          };
          voiceRecognition.onerror=e=>{voiceUsingRecognition=false;showVoiceHelp(e?.error==='not-allowed'?'⚠️ اسمح للمتصفح بالميكروفون ثم جرّب مرة أخرى.':'⚠️ تعذر التقاط الصوت؛ استخدم الكتابة إذا استمر الخطأ.');};
          voiceRecognition.onend=()=>{voiceUsingRecognition=false;voiceAI?.classList.remove('listening');if(voiceMode&&!voiceBusy&&!voiceRecognitionRestart)setTimeout(startListening,700);};
        }
        voiceRecognitionRestart=false; voiceRecognition.start(); return;
      }catch(_){voiceUsingRecognition=false;}
    }
    showVoiceHelp('⚠️ لا يمكن تشغيل الميكروفون في هذا المتصفح. استخدم الكتابة أو ميكروفون لوحة المفاتيح.');
  }
  function stopListening(){
    if(voiceUsingRecognition&&voiceRecognition){voiceRecognitionRestart=true;try{voiceRecognition.stop()}catch(_){}voiceUsingRecognition=false;showVoiceHelp('⏳ جاري معالجة كلامك…');return;}
    if(mediaRecorder?.state==='recording'){showVoiceHelp('⏳ جاري إرسال التسجيل…');mediaRecorder.stop();}
  }
  if(voiceAI){
    voiceAI.addEventListener('click',()=>{
      if(voiceMode){if(mediaRecorder?.state==='recording'){stopListening();return;}voiceMode=false;voiceRecognitionRestart=true;try{voiceRecognition?.stop()}catch(_){}voiceUsingRecognition=false;stopVoiceStream();try{voiceAudio?.pause()}catch(_){}voiceAI.textContent='🎙️ محادثة مباشرة مع العسول';voiceAI.classList.remove('listening');showVoiceHelp('تم إيقاف المحادثة الصوتية.');return;}
      voiceMode=true;
      try{window.speechSynthesis?.getVoices?.(); window.speechSynthesis?.cancel?.();}catch(_){}
      showVoiceHelp('🎙️ محادثة مباشرة: تكلم فقط، وسيتوقف التسجيل تلقائيًا بعد انتهاء كلامك. بعد الرد سأستمع لك من جديد.');
      startListening();
    });
  }
  if(askButton)askButton.addEventListener("click",()=>ask(question?question.value:""));
  if(question)question.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();ask(question.value);}});

  // Homepage voice shortcut: capture Arabic speech then open the real AI chat with the question.
  const homeVoice=document.querySelector("#homeVoiceAI");
  const homeVoiceStatus=document.querySelector("#homeVoiceStatus");
  const HomeSR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(homeVoice){
    if(HomeSR){
      const hr=new HomeSR(); hr.lang="ar-SA"; hr.interimResults=false; hr.continuous=false; hr.maxAlternatives=1;
      hr.onstart=()=>{homeVoice.textContent="🛑 استمع..."; if(homeVoiceStatus)homeVoiceStatus.textContent="🎙️ العسول يستمع… تحدث الآن.";};
      hr.onresult=e=>{const text=e.results?.[0]?.[0]?.transcript?.trim()||""; if(text){if(searchInput)searchInput.value=text; window.location.href="ai.html?question="+encodeURIComponent(text);}};
      hr.onerror=e=>{if(homeVoiceStatus)homeVoiceStatus.textContent=e.error==="not-allowed"?"⚠️ اسمح للمتصفح باستخدام الميكروفون ثم حاول مرة أخرى.":"تعذر التقاط الصوت؛ جرّب مرة أخرى أو استخدم ميكروفون لوحة المفاتيح.";};
      hr.onend=()=>{homeVoice.textContent="🎙️ تحدث";};
      homeVoice.addEventListener("click",()=>{try{hr.start();}catch(e){}});
    }else{
      homeVoice.addEventListener("click",()=>{if(homeVoiceStatus)homeVoiceStatus.textContent="🎙️ هذا المتصفح لا يدعم التحدث المباشر. استخدم ميكروفون لوحة مفاتيح الهاتف، ثم افتح العسول AI.";});
    }
  }

  // Allow links from the homepage to open the AI chat with a prefilled question.
  if(conversation && question){
    const params=new URLSearchParams(location.search);
    const initialQuestion=params.get("question");
    if(location.hash==="#ai-chat" || params.get("chat")==="1"){
      setTimeout(()=>{ document.getElementById("ai-chat")?.scrollIntoView({behavior:"smooth",block:"start"}); question.focus({preventScroll:true}); },80);
    }
    if(initialQuestion) setTimeout(()=>ask(initialQuestion),180);
  }
  quickPrompts.forEach(btn=>btn.addEventListener("click",()=>ask(btn.dataset.question||"")));

});

// V392: resilient offline/static shell with connection feedback. Dynamic AI, Stripe, API and health calls stay network-only.
if ("serviceWorker" in navigator && window.isSecureContext) {
  let alassaulRefreshing = false;
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    // Apply a newly activated shell once, without creating a reload loop.
    if (alassaulRefreshing) return;
    alassaulRefreshing = true;
    window.location.reload();
  });
  window.addEventListener("load", async () => {
    try {
      const registration = await navigator.serviceWorker.register("./sw.js", {scope:"./"});
      const activateWaitingWorker = () => {
        if (registration.waiting) registration.waiting.postMessage({type:"SKIP_WAITING"});
      };
      if (registration.waiting) activateWaitingWorker();
      registration.addEventListener("updatefound", () => {
        const worker = registration.installing;
        if (!worker) return;
        worker.addEventListener("statechange", () => {
          if (worker.state === "installed" && navigator.serviceWorker.controller) activateWaitingWorker();
        });
      });
      registration.update().catch(() => {});
    } catch (_) {}
  }, {once:true});
}


/* V413 mobile navigation */
document.addEventListener('DOMContentLoaded', function () {
  const topbar = document.querySelector('.topbar');
  const toggle = document.querySelector('.mobile-menu-toggle');
  const nav = document.getElementById('main-nav');
  if (!topbar || !toggle || !nav) return;

  toggle.addEventListener('click', function () {
    const open = topbar.classList.toggle('nav-open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'إغلاق القائمة' : 'فتح القائمة');
  });

  nav.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', function () {
      topbar.classList.remove('nav-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'فتح القائمة');
    });
  });
});

/* V415 master mobile menu */
document.addEventListener('DOMContentLoaded',function(){
  const b=document.querySelector('.master-menu-toggle');
  const n=document.getElementById('master-nav-mobile');
  if(!b||!n)return;
  b.addEventListener('click',function(){
    const open=n.classList.toggle('open');
    b.setAttribute('aria-expanded',String(open));
  });
  n.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>n.classList.remove('open')));
});

/* V416: newsletter always has a working fallback path */
function newsletterSubscribe(event){
  if(event) event.preventDefault();
  const form=event?.currentTarget || document.querySelector('.newsletter-form');
  const email=form?.querySelector('input[type="email"]')?.value.trim();
  const status=form?.querySelector('.newsletter-status');
  if(!email){ if(status) status.textContent='فضلاً أدخل بريدك الإلكتروني.'; return false; }
  const subject=encodeURIComponent('طلب الاشتراك في نشرة ALASSAUL');
  const body=encodeURIComponent('أرغب في الاشتراك في نشرة ALASSAUL.\nالبريد: '+email);
  if(status) status.textContent='تم تجهيز طلب الاشتراك — سيتم فتح البريد لإرساله.';
  window.location.href='mailto:info@alassaul.com?subject='+subject+'&body='+body;
  return false;
}

/* V419: platform-wide search, welcome message, dua strip */
document.addEventListener("DOMContentLoaded",()=>{
  const searchInputs=[...document.querySelectorAll(".globalSearch")];
  const runGlobalSearch=(value)=>{
    const q=(value||"").trim(); if(!q) return;
    window.location.href="search.html?q="+encodeURIComponent(q);
  };
  document.querySelectorAll(".globalSearchBtn").forEach(b=>b.addEventListener("click",()=>runGlobalSearch(b.parentElement.querySelector(".globalSearch")?.value)));
  searchInputs.forEach(i=>i.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();runGlobalSearch(i.value);}}));

  if(location.pathname.endsWith("/index.html")||location.pathname.endsWith("/")){
    if(!sessionStorage.getItem("alassaul-welcomed")){
      const card=document.createElement("section"); card.className="welcome-card container";
      card.innerHTML='<h2>أهلًا وسهلًا بك في العسول 🌿</h2><p>بوابتك الذكية للشمال التركي. أنا العسول AI وسأساعدك في الطريق، الأماكن، الفنادق، المطاعم، الطقس، العملات والكاميرات.</p><a class="btn btn-gold" href="ai.html">🎙️ تحدث مع العسول</a>';
      document.querySelector("main")?.prepend(card); sessionStorage.setItem("alassaul-welcomed","1");
    }
  }
  const duas=["رب اشرح لي صدري ويسر لي أمري.","رب زدني علماً.","حسبي الله لا إله إلا هو عليه توكلت وهو رب العرش العظيم.","اللهم إني أسألك علماً نافعاً ورزقاً طيباً وعملاً متقبلاً.","سبحان الله وبحمده، سبحان الله العظيم."];
  const strip=document.createElement("div"); strip.className="dua-strip"; strip.innerHTML='<div class="container"><strong>🤲 ذكر اليوم:</strong> <span id="duaTicker"></span></div>';
  document.body.insertBefore(strip,document.body.firstElementChild?.nextElementSibling||document.body.firstChild);
  let di=0; const ticker=strip.querySelector("#duaTicker"); const show=()=>{if(ticker)ticker.textContent=duas[di%duas.length];di++;}; show(); setInterval(show,7000);
  const next=document.querySelector("#nextDua"); if(next) next.addEventListener("click",()=>{di++;show();});
});
