const json = (statusCode, body, extraHeaders = {}) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    ...extraHeaders
  },
  body: JSON.stringify(body)
});

const buckets = globalThis.__ALASSAUL_AI_BUCKETS || (globalThis.__ALASSAUL_AI_BUCKETS = new Map());
const WINDOW_MS = 60_000, MAX_REQUESTS = 20, MAX_BODY_BYTES = 24_000;
const clientKey = (request) => String(request.headers?.get?.("x-nf-client-connection-ip") || request.headers?.get?.("x-forwarded-for") || "unknown").split(",")[0].trim().slice(0,80) || "unknown";
const allowedByRate = (request) => {
  const key=clientKey(request), now=Date.now();
  if(buckets.size>500) for(const [k,v] of buckets) if(now-v.started>120000) buckets.delete(k);
  const b=buckets.get(key)||{started:now,count:0};
  if(now-b.started>=WINDOW_MS){buckets.set(key,{started:now,count:1});return true;}
  if(b.count>=MAX_REQUESTS)return false; b.count++; buckets.set(key,b); return true;
};

const needsWeb = (text) => /اليوم|الآن|الان|حاليا|حالياً|أخبار|خبر|طقس|جو|درجة الحرارة|سعر|أسعار|مفتوح|يفتح|يغلق|موعد|مواعيد|رحلة|رحلات|ازدحام|فعاليات|حدث|2026|today|now|news|weather|price|open|hours/i.test(String(text||""));
const getProvider = () => {
  // Prefer Netlify's dedicated Gateway credentials when present. Netlify documents
  // these as always injected for supported runtimes; OPENAI_* is the provider-compatible fallback.
  const key = process.env.NETLIFY_AI_GATEWAY_KEY || process.env.OPENAI_API_KEY || process.env.ALASSAUL_AI_API_KEY || process.env.AI_API_KEY || process.env.VITE_NETLIFY_AI_KEY;
  const raw = String(process.env.NETLIFY_AI_GATEWAY_BASE_URL || process.env.OPENAI_BASE_URL || "").trim().replace(/\/+$/,"");
  if(!key || !raw) return null;
  // Accept either an origin, /v1, or a full OpenAI-compatible API base.
  const base = /\/v1$/i.test(raw) ? raw : `${raw}/v1`;
  return {key,base};
};

export default async (request) => {
  const requestId=globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
  if(request.method!=="POST") return json(405,{ok:false,message:"Method not allowed"},{Allow:"POST"});
  if(!allowedByRate(request)) return json(429,{ok:false,code:"AI_RATE_LIMIT",message:"تم الوصول إلى الحد المؤقت للطلبات. حاول بعد قليل."},{"Retry-After":"30"});
  let body;
  try{
    const raw=await request.text();
    if(new TextEncoder().encode(raw).byteLength>MAX_BODY_BYTES) return json(413,{ok:false,code:"AI_REQUEST_TOO_LARGE",message:"الطلب أكبر من الحد المسموح."});
    body=JSON.parse(raw);
  }catch{return json(400,{ok:false,code:"AI_INVALID_JSON",message:"تعذر قراءة الطلب."});}
  const question=String(body?.question||"").trim().slice(0,1600);
  if(!question)return json(400,{ok:false,code:"AI_EMPTY_QUESTION",message:"اكتب سؤالك أولًا."});

  const provider=getProvider();
  if(!provider) return json(503,{ok:false,code:"AI_GATEWAY_NOT_READY",message:"العسول AI لم يتصل بعد بمحرك الذكاء الاصطناعي في Netlify. لا يوجد جواب محلي مزيف لهذا السؤال.",diagnostic:{hasApiKey:Boolean(process.env.OPENAI_API_KEY||process.env.NETLIFY_AI_GATEWAY_KEY||process.env.ALASSAUL_AI_API_KEY||process.env.AI_API_KEY||process.env.VITE_NETLIFY_AI_KEY),hasBaseUrl:Boolean(process.env.OPENAI_BASE_URL||process.env.NETLIFY_AI_GATEWAY_BASE_URL),keySource:process.env.NETLIFY_AI_GATEWAY_KEY?"NETLIFY_AI_GATEWAY_KEY":process.env.OPENAI_API_KEY?"OPENAI_API_KEY":process.env.ALASSAUL_AI_API_KEY?"ALASSAUL_AI_API_KEY":process.env.AI_API_KEY?"AI_API_KEY":process.env.VITE_NETLIFY_AI_KEY?"VITE_NETLIFY_AI_KEY":"none",baseSource:process.env.NETLIFY_AI_GATEWAY_BASE_URL?"NETLIFY_AI_GATEWAY_BASE_URL":process.env.OPENAI_BASE_URL?"OPENAI_BASE_URL":"none"}});

  const context=String(body?.context||"").slice(0,7000);
  const history=Array.isArray(body?.history)?body.history.slice(-10).map(x=>({role:x?.role==='assistant'?'assistant':'user',content:String(x?.content||'').slice(0,1200)})).filter(x=>x.content.trim()):[];
  const system=`أنت العسول AI، المساعد العام الرسمي لمنصة ALASSAUL. تخصصك السفر والشمال التركي، لكنك تساعد أيضًا في المعلومات العامة والتعليم والبرمجة والتقنية والكتابة والتنظيم.\n\nقواعد مهمة: أجب عن السؤال نفسه مباشرة، ولا تغيّر الموضوع. لا تعيد الترحيب في كل رسالة. إذا كانت المعلومة متغيرة فاذكر أنها تحتاج تحققًا حديثًا واستخدم أداة البحث إذا كانت متاحة. لا تخترع كاميرا أو بثًا أو سعرًا أو موعدًا. في الدين قدم معلومات موثوقة ولا تتظاهر بأنك مفتي. في الطب والقانون والمال قدم معلومات عامة حذرة. إذا لم تعرف قل ذلك بوضوح. كن عربيًا واضحًا، طبيعيًا، محترمًا، مختصرًا ومفيدًا.\n\nبيانات ALASSAUL المحلية للاسترشاد فقط:\n${context}`;
  const messages=[{role:'system',content:system},...history,{role:'user',content:question}];
  const model=process.env.ALASSAUL_AI_MODEL||process.env.OPENAI_MODEL||'gpt-5-mini';
  // Use the OpenAI Responses API: it is the current path recommended by Netlify for GPT-5-class models.
  // Do not send temperature/max_tokens here because GPT-5-class models can reject legacy sampling parameters.
  const input=messages.map(m=>({role:m.role,content:m.content}));
  const payload={model,input,max_output_tokens:900};

  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),30000);
  try{
    const headers={Authorization:`Bearer ${provider.key}`,"Content-Type":"application/json"};
    // Prefer Responses API for GPT-5-class models, but fall back to the
    // OpenAI-compatible Chat Completions endpoint because some custom/Gateway
    // providers expose only that compatibility surface.
    const responsesPayload={model,input,max_output_tokens:900};
    const chatPayload={model,messages,max_tokens:900};
    let lastStatus=0, lastCode=null, lastMessage='';
    const call=async(endpoint,payload)=>{
      const r=await fetch(endpoint,{method:'POST',headers,body:JSON.stringify(payload),signal:controller.signal});
      const d=await r.json().catch(()=>({}));
      lastStatus=r.status;
      lastCode=d?.error?.code||null;
      lastMessage=d?.error?.message||'';
      return {r,d};
    };
    let result=await call(`${provider.base}/responses`,responsesPayload);
    let d=result.d, r=result.r;
    if(!r.ok){
      // Compatibility fallback for providers that reject /responses (404/405)
      // or explicitly report an unsupported endpoint.
      const fallbackStatuses=new Set([400,404,405,422]);
      if(fallbackStatuses.has(r.status) || /responses|unsupported|not.?found|endpoint/i.test(lastMessage)){
        result=await call(`${provider.base}/chat/completions`,chatPayload);
        d=result.d; r=result.r;
      }
    }
    if(!r.ok){
      console.error('AI provider error',lastStatus,lastCode,lastMessage);
      return json(502,{ok:false,code:"AI_PROVIDER_ERROR",message:`محرك العسول متصل لكن مزود الذكاء رفض الطلب (${lastStatus}).`,providerStatus:lastStatus,providerCode:lastCode,providerMessage:lastMessage.slice(0,300),requestId});
    }
    const answer=String(d?.output_text||d?.output?.flatMap?.(x=>x?.content||[]).map?.(x=>x?.text||'').join(' ')||d?.choices?.[0]?.message?.content||"").trim();
    if(!answer)return json(502,{ok:false,code:"AI_EMPTY",message:"المحرك لم يرجع إجابة.",requestId});
    return json(200,{ok:true,answer,live:false,model,requestId});
  }catch(e){
    return json(502,{ok:false,code:e?.name==='AbortError'?"AI_TIMEOUT":"AI_NETWORK_ERROR",message:"تعذر الوصول لمحرك العسول الآن. لم أستبدل إجابتك بتخمين.",requestId});
  }finally{clearTimeout(timer);}
};
