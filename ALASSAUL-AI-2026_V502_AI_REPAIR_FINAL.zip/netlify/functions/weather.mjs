const json=(status,body)=>({statusCode:status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"},body:JSON.stringify(body)});
export default async (request)=>{
  const u=new URL(request.url); const lat=Number(u.searchParams.get('lat')); const lng=Number(u.searchParams.get('lng'));
  if(!Number.isFinite(lat)||!Number.isFinite(lng)||lat<-90||lat>90||lng<-180||lng>180)return json(400,{ok:false,message:'إحداثيات غير صحيحة'});
  const url=`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=5`;
  try{const r=await fetch(url,{headers:{Accept:'application/json'}});if(!r.ok)return json(502,{ok:false,message:'تعذر الوصول إلى مصدر الطقس'});const d=await r.json();return json(200,{ok:true,source:'Open-Meteo',data:d});}
  catch{return json(502,{ok:false,message:'تعذر الاتصال بمصدر الطقس'});}
};
export const config={path:'/api/weather'};
