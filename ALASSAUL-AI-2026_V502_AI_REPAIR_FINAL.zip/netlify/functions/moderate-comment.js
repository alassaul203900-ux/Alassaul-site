exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return {statusCode:405,headers:{'Allow':'POST'},body:'Method Not Allowed'};
  try {
    const body = JSON.parse(event.body || '{}');
    const text = String(body.comment || '').replace(/[\u0000-\u001F\u007F]/g,' ').replace(/\s+/g,' ').trim();
    if (!text || text.length > 800) return json(400,{ok:false,reason:'invalid'});
    const blocked = [
      /(?:fuck|shit|bitch|asshole|bastard|dick|cunt)/i,
      /(?:كسم|كس|شرموط|شرموطة|قحبة|زب|منيوك|يلعن|خرا|وسخ|حقير|كلب)/i
    ];
    if (blocked.some(rx=>rx.test(text))) return json(422,{ok:false,reason:'abuse'});
    const links=(text.match(/(?:https?:\/\/|www\.)/gi)||[]).length;
    const emails=(text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)||[]).length;
    if (links>2 || emails>2 || /(.)\1{8,}/u.test(text)) return json(422,{ok:false,reason:'spam'});
    if (/<[^>]+>|javascript\s*:/i.test(text)) return json(422,{ok:false,reason:'unsafe'});
    return json(200,{ok:true,text});
  } catch {
    return json(400,{ok:false,reason:'bad_request'});
  }
};
function json(status, data) {
  return {statusCode:status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify(data)};
}
