const json=(status,body)=>new Response(JSON.stringify(body),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});
export default async (req)=>{
  if(req.method!=="POST") return json(405,{ok:false,error:"Method Not Allowed"});
  const key=process.env.RESEND_API_KEY;
  const from=process.env.ALASSAUL_FROM_EMAIL;
  if(!key||!from) return json(503,{ok:false,error:"Email service is not configured yet."});
  try{
    const b=await req.json();
    const email=String(b.email||"").trim();
    const subject=String(b.subject||"رحلتي مع ALASSAUL").slice(0,160);
    const html=String(b.html||"").slice(0,12000);
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||!html) return json(400,{ok:false,error:"Invalid email or content"});
    const r=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Authorization":`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify({from,to:[email],subject,html})});
    const data=await r.json().catch(()=>({}));
    if(!r.ok) return json(502,{ok:false,error:"Email provider rejected the message"});
    return json(200,{ok:true,id:data.id||null});
  }catch{return json(400,{ok:false,error:"Bad request"});}
};
