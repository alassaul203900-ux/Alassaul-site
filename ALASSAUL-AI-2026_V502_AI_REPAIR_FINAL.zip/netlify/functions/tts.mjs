const json = (status, body, headers = {}) => ({
  statusCode: status,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers },
  body: JSON.stringify(body)
});

export default async (request) => {
  if (request.method !== "POST") return json(405, { ok:false, message:"Method not allowed" }, { Allow:"POST" });
  let body;
  try { body = JSON.parse(await request.text()); } catch { return json(400, {ok:false,message:"Invalid JSON"}); }
  const input = String(body?.text || "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim().slice(0, 3500);
  if (!input) return json(400, {ok:false,message:"Text is required"});

  const apiKey = process.env.NETLIFY_AI_GATEWAY_KEY || process.env.OPENAI_API_KEY || process.env.ALASSAUL_AI_API_KEY || process.env.AI_API_KEY;
  const rawBase = String(process.env.NETLIFY_AI_GATEWAY_BASE_URL || process.env.OPENAI_BASE_URL || "https://api.openai.com").replace(/\/$/, "");
  const base = rawBase.endsWith("/v1") ? rawBase : `${rawBase}/v1`;
  if (!apiKey) return json(503, {ok:false,code:"TTS_NOT_CONFIGURED",message:"الصوت الرجالي يحتاج تفعيل خدمة AI في Netlify."});

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 25000);
  try {
    const r = await fetch(`${base}/audio/speech`, {
      method:"POST",
      headers:{ Authorization:`Bearer ${apiKey}`, "Content-Type":"application/json" },
      body:JSON.stringify({
        model:"gpt-4o-mini-tts",
        voice: process.env.ALASSAUL_TTS_VOICE || "cedar",
        input,
        instructions:"تحدث بالعربية بصوت رجل عربي واضح ودافئ وودود، بأسلوب مساعد شخصي محترم، نبرة طبيعية غير آلية، سرعة هادئة ومتوسطة، مخارج حروف واضحة، وتوقفات قصيرة بين الأفكار. لا تتحدث بسرعة ولا بنبرة مذيع.",
        speed: Number(process.env.ALASSAUL_TTS_SPEED || 0.96),
        response_format:"mp3"
      }),
      signal:controller.signal
    });
    if(!r.ok){
      const detail = await r.text().catch(()=>"");
      console.error("TTS error", r.status, detail.slice(0,300));
      return json(502,{ok:false,code:"TTS_PROVIDER_ERROR",message:"تعذر تشغيل الصوت الرجالي الآن."});
    }
    const buf = Buffer.from(await r.arrayBuffer());
    return {
      statusCode:200,
      headers:{"Content-Type":"audio/mpeg","Cache-Control":"no-store","X-AI-Generated-Voice":"true"},
      isBase64Encoded:true,
      body:buf.toString("base64")
    };
  } catch(e){
    return json(502,{ok:false,code:e?.name==="AbortError"?"TTS_TIMEOUT":"TTS_NETWORK_ERROR",message:"تعذر الاتصال بخدمة الصوت الآن."});
  } finally { clearTimeout(timer); }
};
