import fs from 'node:fs';
import path from 'node:path';
export default async () => {
  try {
    const file = path.join(process.cwd(),'data','content-status.json');
    const data = JSON.parse(fs.readFileSync(file,'utf8'));
    return {statusCode:200,headers:{'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify({ok:true,...data})};
  } catch {
    return {statusCode:500,headers:{'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify({ok:false})};
  }
};
export const config = {path:'/api/content-status'};
