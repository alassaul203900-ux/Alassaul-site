const json=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
export default async()=>{
  const gatewayKey=Boolean(process.env.NETLIFY_AI_GATEWAY_KEY);
  const gatewayBase=String(process.env.NETLIFY_AI_GATEWAY_BASE_URL||'');
  const providerKey=Boolean(process.env.OPENAI_API_KEY||process.env.ALASSAUL_AI_API_KEY||process.env.AI_API_KEY||process.env.VITE_NETLIFY_AI_KEY);
  const providerBase=String(process.env.OPENAI_BASE_URL||'');
  const hasKey=gatewayKey||providerKey;
  const base=gatewayBase||providerBase;
  const checks={search:true,maps:true,contactForm:true,aiAssistant:hasKey&&Boolean(base),stripeCheckout:Boolean(process.env.STRIPE_SECRET_KEY&&process.env.STRIPE_PRICE_ID),seo:true};
  return json({ok:true,version:'ALASSAUL-AI-2026-V502',checkedAt:new Date().toISOString(),checks,ai:{configured:checks.aiAssistant,hasKey,hasBaseUrl:Boolean(base),gateway:gatewayKey&&gatewayBase?'Netlify AI Gateway':providerKey&&providerBase?'OpenAI/custom provider':'not configured',gatewayInjected:{key:gatewayKey,baseUrl:Boolean(gatewayBase)},providerConfigured:{key:providerKey,baseUrl:Boolean(providerBase)},model:process.env.ALASSAUL_AI_MODEL||process.env.OPENAI_MODEL||'gpt-5-mini'},externalSetup:{ai:checks.aiAssistant?'ready':'not_ready'},policy:'Health monitor only; secrets are never returned.'});
};
