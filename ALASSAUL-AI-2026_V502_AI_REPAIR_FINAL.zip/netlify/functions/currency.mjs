const json=(status,body)=>({statusCode:status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"},body:JSON.stringify(body)});
export default async (request)=>{
  const u=new URL(request.url); const base=String(u.searchParams.get('base')||'USD').toUpperCase(); const symbols=String(u.searchParams.get('symbols')||'TRY,USD,EUR,SAR,GBP').toUpperCase();
  if(!/^[A-Z]{3}$/.test(base)||!/^([A-Z]{3},?)+$/.test(symbols))return json(400,{ok:false,message:'رمز عملة غير صحيح'});
  try{const r=await fetch(`https://api.frankfurter.dev/v1/latest?base=${encodeURIComponent(base)}&symbols=${encodeURIComponent(symbols)}`,{headers:{Accept:'application/json'}});if(!r.ok)return json(502,{ok:false,message:'تعذر الوصول إلى مصدر العملات'});const d=await r.json();return json(200,{ok:true,...d,source:'Frankfurter'});}
  catch{return json(502,{ok:false,message:'تعذر الاتصال بمصدر العملات'});}
};
export const config={path:'/api/currency'};
