const json=(status,body,headers={})=>({statusCode:status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store",...headers},body:JSON.stringify(body)});
export default async (request)=>{
  if(request.method!=="POST") return json(405,{ok:false,message:"Method not allowed"},{Allow:"POST"});
  const apiKey=process.env.NETLIFY_AI_GATEWAY_KEY||process.env.OPENAI_API_KEY;
  const rawBase=String(process.env.NETLIFY_AI_GATEWAY_BASE_URL||process.env.OPENAI_BASE_URL||"https://api.openai.com").replace(/\/$/,"");
  const base=rawBase.endsWith("/v1")?rawBase:`${rawBase}/v1`;
  if(!apiKey) return json(503,{ok:false,code:"TRANSCRIBE_NOT_CONFIGURED",message:"التعرف الصوتي يحتاج تفعيل خدمة الصوت في Netlify."});
  try{
    const form=await request.formData();
    const file=form.get("file");
    if(!file || typeof file.arrayBuffer!=="function") return json(400,{ok:false,code:"AUDIO_MISSING",message:"لم يصل تسجيل صوتي."});
    const size=Number(file.size||0);
    if(!size || size>12*1024*1024) return json(413,{ok:false,code:"AUDIO_TOO_LARGE",message:"تسجيل الصوت أكبر من الحد المسموح."});
    const upstream=new FormData();
    const type=String(file.type||"audio/webm") || "audio/webm";
    upstream.append("file",new Blob([await file.arrayBuffer()],{type}),String(file.name||"speech.webm"));
    upstream.append("model",process.env.ALASSAUL_TRANSCRIBE_MODEL||"gpt-4o-mini-transcribe");
    upstream.append("language","ar");
    upstream.append("prompt","المستخدم يتحدث بالعربية عن السفر في تركيا والشمال التركي: طرابزون، أوزنجول، ريزا، آيدر، سوميلا، الفنادق، المطاعم، الطقس، العملات، الخرائط.");
    const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),25000);
    try{
      const r=await fetch(`${base}/audio/transcriptions`,{method:"POST",headers:{Authorization:`Bearer ${apiKey}`},body:upstream,signal:controller.signal});
      const d=await r.json().catch(()=>({}));
      if(!r.ok) return json(502,{ok:false,code:"TRANSCRIBE_PROVIDER_ERROR",message:"تعذر تحويل الصوت إلى نص الآن."});
      const text=String(d.text||"").trim();
      if(!text) return json(422,{ok:false,code:"TRANSCRIBE_EMPTY",message:"لم أفهم الكلام الصوتي. حاول مرة أخرى."});
      return json(200,{ok:true,text});
    } finally { clearTimeout(timer); }
  }catch(e){
    return json(502,{ok:false,code:e?.name==="AbortError"?"TRANSCRIBE_TIMEOUT":"TRANSCRIBE_NETWORK_ERROR",message:"تعذر الاتصال بخدمة التعرف على الصوت."});
  }
};
