import Stripe from "stripe";

const stripeSecret = process.env.STRIPE_SECRET_KEY;
const priceId = process.env.STRIPE_PRICE_ID;

export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method Not Allowed" }), {
      status: 405, headers: { "content-type": "application/json" }
    });
  }
  if (!stripeSecret || !priceId) {
    return new Response(JSON.stringify({
      error: "Stripe server settings are not configured yet."
    }), { status: 503, headers: { "content-type": "application/json" }});
  }
  try {
    const stripe = new Stripe(stripeSecret);
    const origin = new URL(req.url).origin;
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${origin}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/contact.html?payment=cancelled`,
      locale: "ar"
    });
    return new Response(JSON.stringify({ url: session.url }), {
      status: 200, headers: { "content-type": "application/json" }
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: "Unable to create checkout session." }), {
      status: 500, headers: { "content-type": "application/json" }
    });
  }
};
