/* ALASSAUL Stripe client: never contains a secret key. */
(function () {
  function setStatus(message) {
    const el = document.getElementById("paymentStatus");
    if (el) el.textContent = message;
  }
  async function startCheckout() {
    setStatus("جاري تجهيز الدفع التجريبي…");
    try {
      const response = await fetch("/.netlify/functions/create-checkout", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({mode: "subscription"})
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.url) {
        throw new Error(data.error || "تعذر إنشاء جلسة الدفع.");
      }
      window.location.href = data.url;
    } catch (error) {
      setStatus("الدفع التجريبي غير مفعّل بعد على Netlify. سيتم تفعيله بعد إضافة إعدادات Stripe السرية.");
      console.warn("Stripe checkout:", error);
    }
  }
  document.addEventListener("DOMContentLoaded", function () {
    const button = document.getElementById("subscribeButton");
    if (button) button.addEventListener("click", startCheckout);
  });
})();
