(() => {
  const run = async () => {
    const checks = ['/api/content-status','/.netlify/functions/health'];
    const results = {};
    for (const url of checks) {
      try {
        const r = await fetch(url,{cache:'no-store'});
        results[url] = r.ok;
      } catch { results[url] = false; }
    }
    const ok = Object.values(results).every(Boolean);
    document.documentElement.dataset.systemHealth = ok ? 'ok' : 'check';
    window.ALASSAUL_SYSTEM_HEALTH = {ok, checks:results, checkedAt:new Date().toISOString()};
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run, {once:true});
  else run();
})();
