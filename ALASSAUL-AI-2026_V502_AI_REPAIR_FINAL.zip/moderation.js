(() => {
  const blocked = [
    /(?:fuck|shit|bitch|asshole|bastard|dick|cunt)/i,
    /(?:كسم|كس|شرموط|شرموطة|قحبة|زب|منيوك|يلعن|خرا|وسخ|حقير|كلب)/i
  ];
  const normalize = s => String(s || '').replace(/[\u0000-\u001F\u007F]/g,' ').replace(/\s+/g,' ').trim();
  const repeated = s => /(.)\1{8,}/u.test(s);
  const spam = s => {
    const links = (s.match(/(?:https?:\/\/|www\.)/gi)||[]).length;
    const emails = (s.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)||[]).length;
    return links > 2 || emails > 2 || repeated(s);
  };
  window.ALASSAUL_MODERATION = {
    check(text) {
      const value = normalize(text);
      if (!value) return {ok:false, reason:'empty'};
      if (value.length > 800) return {ok:false, reason:'too_long'};
      if (blocked.some(rx => rx.test(value))) return {ok:false, reason:'abuse'};
      if (spam(value)) return {ok:false, reason:'spam'};
      return {ok:true, text:value};
    },
    sanitize(text) {
      const d=document.createElement('div'); d.textContent=normalize(text); return d.textContent;
    }
  };
  document.addEventListener('submit', e => {
    const form=e.target;
    if (!form.matches('.comment-form,[data-comment-form]')) return;
    const input=form.querySelector('textarea,[name="comment"]');
    const status=form.querySelector('[data-moderation-status]');
    const result=window.ALASSAUL_MODERATION.check(input?.value);
    if (!result.ok) {
      e.preventDefault();
      if(status) status.textContent = result.reason==='abuse'
        ? 'تم رفض التعليق لأنه يحتوي على محتوى مسيء.'
        : 'لم يتم إرسال التعليق. يرجى مراجعته والمحاولة مرة أخرى.';
      return;
    }
    if (input) input.value=window.ALASSAUL_MODERATION.sanitize(result.text);
  });
})();
