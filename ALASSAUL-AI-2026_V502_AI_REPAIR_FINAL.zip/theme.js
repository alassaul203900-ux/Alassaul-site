// ALASSAUL 2026 - Smart Theme System

const ALASSAUL_THEME = {

seasons: {
spring: {
name: "ربيع الشمال التركي",
primary: "#2f6b45",
secondary: "#4db6ac",
mood: "fresh"
},

summer: {
name: "صيف البحر الأسود",
primary: "#176b87",
secondary: "#42c2ff",
mood: "bright"
},

autumn: {
name: "خريف الغابات",
primary: "#8b5a2b",
secondary: "#c9a227",
mood: "warm"
},

winter: {
name: "شتاء الضباب والثلوج",
primary: "#315b73",
secondary: "#dfeff5",
mood: "snow"
}
},

getSeason() {

const month = new Date().getMonth() + 1;

if (month >= 3 && month <= 5) return "spring";
if (month >= 6 && month <= 8) return "summer";
if (month >= 9 && month <= 11) return "autumn";

return "winter";
},

getTimeMode() {

const hour = new Date().getHours();

if (hour >= 6 && hour < 18) {
return "day";
}

return "night";
},

applyTheme(modeOverride) {

const season = this.getSeason();
const theme = this.seasons[season];

document.documentElement.style.setProperty("--primary-color", theme.primary);
document.documentElement.style.setProperty("--secondary-color", theme.secondary);
document.documentElement.style.setProperty("--forest", theme.primary);
document.documentElement.style.setProperty("--turquoise", theme.secondary);

document.documentElement.setAttribute(
"data-season",
season
);

const saved = modeOverride || localStorage.getItem("alassaul-theme-mode");
document.documentElement.setAttribute("data-time", saved || this.getTimeMode());
document.documentElement.setAttribute("data-user-theme", saved ? "1" : "0");

}

};

// تشغيل النظام
document.addEventListener("DOMContentLoaded",()=>{
  ALASSAUL_THEME.applyTheme();
  const saved=localStorage.getItem("alassaul-theme-mode");
  document.querySelectorAll(".theme-toggle").forEach(btn=>{
    const sync=()=>{ const mode=document.documentElement.getAttribute("data-time")||"night"; btn.textContent=mode==="night"?"☀️":"🌙"; btn.title=mode==="night"?"التبديل للوضع النهاري":"التبديل للوضع الليلي"; };
    sync();
    btn.addEventListener("click",()=>{
      const current=document.documentElement.getAttribute("data-time")||"night";
      const next=current==="night"?"day":"night";
      localStorage.setItem("alassaul-theme-mode",next);
      ALASSAUL_THEME.applyTheme(next); sync();
    });
  });
});