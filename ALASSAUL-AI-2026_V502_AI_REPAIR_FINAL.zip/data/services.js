/* ALASSAUL 2026 — Central service registry
   Secrets NEVER live in browser files. The AI gateway and Netlify Environment Variables handle private credentials.
*/
window.ALASSAUL_SERVICES = Object.freeze({
  ai: { endpoint: '/.netlify/functions/ai', mode: 'server', secretEnv: 'OPENAI_API_KEY', status: 'ready' },
  currentInfo: { endpoint: '/.netlify/functions/ai', mode: 'ai-web', secretEnv: 'OPENAI_API_KEY', status: 'ready', note: 'Weather, news, prices and other changing facts are handled through the AI web-search gateway.' },
  maps: { mode: 'public-links', status: 'ready', note: 'Google Maps search links; no browser API key required.' },
  liveStreams: { mode: 'verified-registry', status: 'registry-ready', note: 'Only verified public stream URLs are added; empty URLs are never presented as live.' },
  payments: { endpoint: '/.netlify/functions/create-checkout', mode: 'server', secretEnv: 'STRIPE_SECRET_KEY', status: 'ready' }
});

window.ALASSAUL_API_MANAGER = {
  get(name) { return window.ALASSAUL_SERVICES?.[name] || null; },
  publicSummary() {
    return Object.entries(window.ALASSAUL_SERVICES || {}).map(([name, item]) =>
      `${name}: ${item.status || 'unknown'} (${item.mode || 'server'})`).join('\n');
  }
};
