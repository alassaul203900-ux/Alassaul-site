(function(){
  const normalize=value=>String(value||'').toLowerCase().trim()
    .replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي')
    .replace(/[ًٌٍَُِّْـ]/g,'').replace(/[٠-٩]/g,d=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
  const fields=item=>[item.name,item.english,item.description,item.city,item.type,item.id,item.file,...(item.tags||[])].filter(Boolean);
  const match=(item,query)=>{const q=normalize(query); return !q || fields(item).some(v=>normalize(v).includes(q));};
  const servicePages=[
    {id:'service-map',name:'الخرائط والملاحة',description:'افتح خريطة العسول وشاهد مواقع المدن والوجهات.',file:'map.html',tags:['خريطة','خرائط','موقع','ملاحة']},
    {id:'service-weather',name:'الطقس',description:'خدمة الطقس في الوجهات.',file:'weather.html',tags:['طقس','جو','حرارة']},
    {id:'service-currency',name:'تحويل العملات',description:'تحويل العملات والأسعار.',file:'currency.html',tags:['عملة','عملات','ليرة','دولار','يورو']},
    {id:'service-live',name:'الكاميرات والبث المباشر',description:'كاميرات ومصادر بث عامة موثوقة عند توفرها.',file:'live.html',tags:['كاميرا','بث','لايف','مباشر']},
    {id:'service-ai',name:'العسول AI',description:'المساعد الذكي للتخطيط والسفر.',file:'ai.html',tags:['ذكاء','ai','مساعد','تحدث']},
    {id:'service-hotels',name:'الفنادق',description:'دليل الفنادق.',file:'hotels.html',tags:['فندق','فنادق','سكن']},
    {id:'service-restaurants',name:'المطاعم',description:'دليل المطاعم.',file:'restaurants.html',tags:['مطعم','مطاعم','اكل','طعام']},
    {id:'service-transport',name:'المواصلات والدولموش',description:'خيارات التنقل وتأجير السيارات.',file:'transport.html',tags:['مواصلات','دولموش','تاكسي','سيارة','تأجير']},
    {id:'service-programs',name:'الرحلات والبرامج',description:'برامج 4 و5 و7 و10 أيام وغيرها.',file:'programs.html',tags:['برنامج','رحلة','4 ايام','5 ايام','7 ايام','10 ايام']},
    {id:'service-games',name:'الألعاب والترفيه',description:'ألعاب عائلية وسباقات ومحتوى للأطفال والكبار.',file:'games.html',tags:['لعبة','العاب','بلوت','سباق','اطفال','ترفيه']},
    {id:'service-language',name:'تعلم التركية والإنجليزية',description:'تعلم عملي بالصوت والكتابة للسفر والحياة اليومية.',file:'language.html',tags:['تركي','تركية','انجليزي','انجليزية','تعلم','لغة']}
  ];
  window.ALASSAUL_SEARCH={
    normalize,
    searchCities(query){return (window.ALASSAUL_CITIES||[]).filter(x=>match(x,query));},
    searchPlaces(query){return (window.ALASSAUL_PLACES||[]).filter(x=>match(x,query));},
    searchPrograms(query){const q=normalize(query); return (window.ALASSAUL_PROGRAMS||[]).filter(x=>match(x,q)||String(x.days||'').includes(q));},
    searchServices(query){return servicePages.filter(x=>match(x,query));},
    globalSearch(query){
      const q=normalize(query);
      const cities=this.searchCities(q), places=this.searchPlaces(q), programs=this.searchPrograms(q), services=this.searchServices(q);
      return {query:q,cities,places,programs,services,total:cities.length+places.length+programs.length+services.length};
    }
  };
})();