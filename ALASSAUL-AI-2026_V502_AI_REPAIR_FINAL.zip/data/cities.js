window.ALASSAUL_CITIES = [
{id:'trabzon',name:'طرابزون',file:'trabzon.html',description:'مدينة البحر الأسود والطبيعة والتاريخ والأنشطة.',image:'assets/trabzon.jpg',region:'طرابزون',highlights:['سوميلا','حيدر نبي','مغارة تشال','أكشبات','قانيتا','بوزتبه']},
{id:'rize',name:'ريزا',file:'rize.html',description:'مدينة الشاي والجبال والمرتفعات الخضراء والشلالات.',image:'assets/rize-scene.svg',region:'ريزا',highlights:['آيدر','وادي فرتينا','مزارع الشاي','الشلالات']},
{id:'uzungol',name:'أوزنجول',file:'uzungol.html',description:'بحيرة جبلية ساحرة تحيط بها الغابات والمرتفعات.',image:'assets/master-hero-uzungol.jpg',region:'طرابزون',highlights:['البحيرة','الإطلالات','المطاعم','المشي']},
{id:'ayder',name:'آيدر',file:'ayder.html',description:'مرتفعات طبيعية بين الغابات والينابيع والجبال.',image:'assets/ayder-yayla.svg',region:'ريزا',highlights:['المرتفعات','الينابيع','الشلالات','فرتينا']},
{id:'sumela',name:'سوميلا',file:'sumela.html',description:'دير تاريخي جبلي وطبيعة مميزة قرب ماتشكا.',image:'assets/sumela-scene.svg',region:'طرابزون',highlights:['دير سوميلا','ماتشكا','الجبال']},
{id:'samsun',name:'سامسون',file:'cities.html#samsun',description:'مدينة ساحلية مهمة تجمع البحر والثقافة والخدمات.',image:'assets/samsun-scene.svg',region:'سامسون',highlights:['الكورنيش','المتاحف','التلفريك','الأسواق']},
{id:'ordu',name:'أوردو',file:'cities.html#ordu',description:'ساحل البحر الأسود وتلفريك ومناظر جبلية واسعة.',image:'assets/ordu-scene.svg',region:'أوردو',highlights:['التلفريك','بوزتبه أوردو','الساحل']},
{id:'giresun',name:'غيرسون',file:'cities.html#giresun',description:'مدينة ساحلية خضراء بطابع محلي وجزر ومعالم طبيعية.',image:'assets/giresun-scene.svg',region:'غيرسون',highlights:['الساحل','الطبيعة','المعالم المحلية']},
{id:'artvin',name:'آرتفين',file:'cities.html#artvin',description:'جبال ووديان وبحيرات وطبيعة برية في شمال شرق تركيا.',image:'assets/artvin-scene.svg',region:'آرتفين',highlights:['الجبال','البحيرات','الوديان']},
{id:'gumushane',name:'غوموشهانه',file:'cities.html#gumushane',description:'مدينة داخلية تاريخية تحيط بها الجبال والكهوف والطبيعة.',image:'assets/gumushane-scene.svg',region:'غوموشهانه',highlights:['الكهوف','القرى','الجبال']}
];