window.ALASSAUL_PROGRAMS = [
  {days:4, title:'برنامج 4 أيام', description:'طرابزون وأوزنجول وآيدر.'},
  {days:5, title:'برنامج 5 أيام', description:'مزيج متوازن من الطبيعة والمدينة.'},
  {days:7, title:'برنامج 7 أيام', description:'اكتشاف أجمل مناطق البحر الأسود.'},
  {days:10, title:'برنامج 10 أيام', description:'تجربة شاملة للشمال التركي.'}
];
