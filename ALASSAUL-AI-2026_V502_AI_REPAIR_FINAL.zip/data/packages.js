/* ALASSAUL V421 - Package pricing model
   Prices are starting estimates only until supplier/API quotes are connected.
   Base currency: TRY. Display conversion is handled by the currency module.
*/
window.ALASSAUL_PACKAGES = [
 {id:'trabzon-4',name:'طرابزون 4 أيام',days:4,people:2,level:'اقتصادي',baseTry:28500,includes:['إقامة 3 ليالٍ','تنقلات داخلية','جولة طرابزون'],status:'estimate'},
 {id:'trabzon-5',name:'طرابزون 5 أيام',days:5,people:2,level:'متوسط',baseTry:39500,includes:['إقامة 4 ليالٍ','تنقلات','جولات مختارة'],status:'estimate'},
 {id:'blacksea-7',name:'الشمال التركي 7 أيام',days:7,people:2,level:'متوسط',baseTry:56500,includes:['طرابزون','ريزا','أوزنجول','آيدر','إقامة وتنقلات'],status:'estimate'},
 {id:'blacksea-10',name:'الشمال التركي 10 أيام',days:10,people:2,level:'مميز',baseTry:79500,includes:['سامسون','أوردو','غيرسون','طرابزون','ريزا','إقامة وتنقلات'],status:'estimate'}
];
window.ALASSAUL_PRICING_RULES = {
 baseCurrency:'TRY',
 displayCurrencies:['TRY','USD','EUR','SAR','GBP'],
 disclaimer:'السعر المعروض تقديري ويتغير حسب الموسم والفندق والخدمات وتوفر المورد. السعر النهائي يعتمد على عرض حجز مؤكد.'
};
