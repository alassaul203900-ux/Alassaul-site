/* ALASSAUL 2026 — verified live source registry */
window.ALASSAUL_LIVE_STREAMS = Object.freeze([
 {id:'istanbul',name:'إسطنبول',lat:41.0082,lng:28.9784,status:'ready',url:'https://uym.ibb.gov.tr/ibbyolgosteren/'},
 {id:'trabzon',name:'طرابزون',lat:41.0015,lng:39.7178,status:'ready',url:'https://www.trabzon.bel.tr/Web/SehirKameralari'},
 {id:'uzungol',name:'أوزنجول',lat:40.6200,lng:40.2880,status:'ready',url:'https://www.trabzon.bel.tr/Web/SehirKameralari'},
 {id:'rize',name:'ريزا',lat:41.0201,lng:40.5234,status:'ready',url:'https://www.rize.bel.tr/canli-kameralar'},
 {id:'ayder',name:'آيدر',lat:40.9530,lng:41.0950,status:'unavailable',url:''},
 {id:'samsun',name:'سامسون',lat:41.2867,lng:36.3300,status:'unverified',url:''},
 {id:'ordu',name:'أوردو',lat:40.9839,lng:37.8764,status:'unverified',url:''},
 {id:'giresun',name:'غيرسون',lat:40.9128,lng:38.3895,status:'unverified',url:''}
]);