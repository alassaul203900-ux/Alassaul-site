/* ALASSAUL V499 — do not overwrite the real AI health result. */
document.addEventListener('DOMContentLoaded', () => {
  const el = document.getElementById('ai-config-status');
  if (!el) return;
  const endpoint = (window.ALASSAUL_CONFIG && window.ALASSAUL_CONFIG.aiEndpoint) || '/.netlify/functions/ai';
  el.dataset.endpoint = endpoint;
});
