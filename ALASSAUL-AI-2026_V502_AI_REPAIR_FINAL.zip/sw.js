const STATIC_CACHE_NAME = 'alassaul-v498-cache';
const RUNTIME_CACHE_NAME = "alassaul-v498-runtime";
const OFFLINE_URL = "index.html";
const CACHE_PREFIX = "alassaul-";
const MAX_RUNTIME_ENTRIES = 120;
const MAX_RUNTIME_BYTES = 1024 * 1024;
const RUNTIME_PATH_ALLOWLIST = /\.(?:html?|css|js|mjs|json|svg|woff2?|ttf|otf)$/i;
const OFFLINE_FALLBACKS = ["index.html", "404.html"];
const CACHEABLE_TYPES = /^(text\/html|text\/css|text\/javascript|application\/javascript|application\/json|image\/(?:svg\+xml|jpeg|png|webp)|font\/)/i;

async function cacheRuntimeResponse(request, response) {
  if (!response || !response.ok || response.type !== "basic" || response.redirected) return;
  const contentType = response.headers.get("content-type") || "";
  const cacheControl = (response.headers.get("cache-control") || "").toLowerCase();
  if (cacheControl.includes("no-store") || cacheControl.includes("private")) return;
  if ((response.headers.get("vary") || "").trim() === "*") return;
  if (response.headers.has("set-cookie")) return;
  const contentLength = Number(response.headers.get("content-length") || 0);
  if (!CACHEABLE_TYPES.test(contentType) || (contentLength && contentLength > MAX_RUNTIME_BYTES)) return;
  // Only cache predictable static/document paths. This prevents arbitrary same-origin
  // JSON or dynamic endpoints from quietly entering the offline runtime cache.
  const url = new URL(request.url);
  if (url.search || url.hash || !RUNTIME_PATH_ALLOWLIST.test(url.pathname)) return;
  try {
    const cache = await caches.open(RUNTIME_CACHE_NAME);
    // Enforce the 1 MB limit even when the server omits Content-Length.
    if (!contentLength) {
      const body = await response.clone().arrayBuffer();
      if (body.byteLength > MAX_RUNTIME_BYTES) return;
    }
    await cache.put(request, response.clone());
    const keys = await cache.keys();
    if (keys.length > MAX_RUNTIME_ENTRIES) {
      const excess = keys.length - MAX_RUNTIME_ENTRIES;
      await Promise.all(keys.slice(0, excess).map(key => cache.delete(key)));
    }
  } catch (_) {}
}
const STATIC_ASSETS = [
  "index.html", "ai.html", "cities.html", "map.html", "hotels.html", "restaurants.html", "programs.html",
  "trabzon.html", "uzungol.html", "rize.html", "ayder.html", "sumela.html", "contact.html", "credits.html",
  "404.html", "style.css", "script.js", "theme.js", "maintenance.js", "moderation.js", "stripe.js", "stripe-config.js",
  "manifest.webmanifest", "data/config.js", "data/cities.js", "data/places.js", "data/programs.js", "data/packages.js", "data/search.js",
  "data/services.js", "data/live-streams.js", "map/map.js", "assets/runtime-status.js", "data/config.js",
  "assets/hero.jpg", "assets/trabzon.jpg",
  "assets/hero-fallback.svg", "assets/trabzon-fallback.svg", "assets/uzungol-fallback.svg",
  "assets/rize-fallback.svg", "assets/ayder-fallback.svg", "assets/sumela-fallback.svg",
  "assets/logo-alassaul-gold-transparent.png", "data/content-status.json",
  "blog.html",
  "currency.html",
  "live.html",
  "markets.html",
  "media.html",
  "search.html",
  "success.html",
  "transport.html",
  "weather.html",
  "assets/master-hero-uzungol.jpg", "assets/rize-scene.svg", "assets/ayder-scene.svg", "assets/sumela-scene.svg",
  "assets/alassaul-ai-robot-reference.png",
  "assets/samsun-scene.svg", "assets/ordu-scene.svg", "assets/giresun-scene.svg",
  "assets/artvin-scene.svg", "assets/gumushane-scene.svg",
  "assets/logo-gold.svg",
  "assets/ayder-yayla.svg", "assets/ayder-waterfall.svg", "assets/ayder-springs.svg", "assets/ayder-firtina.svg", "assets/rize-tea.svg", "assets/rize-valley.svg", "assets/rize-waterfall.svg", "assets/trabzon-boztepe.svg", "assets/trabzon-meydan.svg", "assets/trabzon-sumela.svg", "assets/uzungol-lake.svg", "assets/uzungol-highlands.svg", "assets/uzungol-villages.svg", "assets/uzungol-activities.svg"];
self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(STATIC_CACHE_NAME);
    // Cache each shell asset independently so one optional/missing asset cannot
    // prevent the new Service Worker from installing.
    await Promise.all(STATIC_ASSETS.map(async asset => {
      try {
        const response = await fetch(new Request(asset, {cache: "no-store"}));
        if (response.ok && response.type === "basic") {
          const contentType = response.headers.get("content-type") || "";
          if (CACHEABLE_TYPES.test(contentType)) await cache.put(asset, response);
        }
      } catch (_) {}
    }));
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", event => {
  event.waitUntil(Promise.all([
    caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith(CACHE_PREFIX) && k !== STATIC_CACHE_NAME && k !== RUNTIME_CACHE_NAME).map(k => caches.delete(k)))),
    self.registration.navigationPreload ? self.registration.navigationPreload.enable().catch(() => {}) : Promise.resolve()
  ]).then(() => self.clients.claim()));
});
self.addEventListener("fetch", event => {
  const req = event.request;
  const url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== self.location.origin) return;
  if (url.pathname.startsWith("/.netlify/") || url.pathname.startsWith("/api/")) return;
  if (req.mode === "navigate") {
    event.respondWith((event.preloadResponse || Promise.resolve(null)).then(preloaded => preloaded || fetch(req)).then(response => {
      if (response && response.ok && response.type === "basic") {
        const copy = response.clone();
        cacheRuntimeResponse(req, copy);
      }
      return response;
    }).catch(() => caches.match(req, {cacheName: RUNTIME_CACHE_NAME}).then(cached => cached || caches.match(req, {cacheName: STATIC_CACHE_NAME}).then(staticCached => staticCached || caches.match(OFFLINE_URL, {cacheName: STATIC_CACHE_NAME}).then(offline => offline || caches.match("404.html", {cacheName: STATIC_CACHE_NAME}))))));
    return;
  }
  // Network-first for same-origin static resources so published updates appear
  // immediately when online; cached assets remain available offline.
  event.respondWith((async () => {
    try {
      const response = await fetch(req);
      if (response && response.ok && response.type === "basic") {
        cacheRuntimeResponse(req, response.clone());
      }
      return response;
    } catch (_) {
      const runtimeCached = await caches.match(req, {cacheName: RUNTIME_CACHE_NAME});
      return runtimeCached || caches.match(req, {cacheName: STATIC_CACHE_NAME});
    }
  })());
});

self.addEventListener("message", event => {
  if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
});
