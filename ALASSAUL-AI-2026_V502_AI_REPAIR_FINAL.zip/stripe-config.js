/* ALASSAUL Stripe client configuration
   Put ONLY the publishable key (pk_...) here if you choose client-side Stripe Elements.
   Never put sk_... in this file or any public website file. */
window.ALASSAUL_STRIPE = {
  publishableKey: (window.ALASSAUL_CONFIG && window.ALASSAUL_CONFIG.stripePublishableKey) || ''
};
